function notifTest() {
  const title = "We are Emperor";
  const options = {
    body: "i am the black wizard, soul who dies for thousand death",
    icon: "/asset/logo/icon265.png",
  };
}
